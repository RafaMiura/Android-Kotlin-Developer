package br.com.fiap.conversordetemperatura

class ConversorDeTemperatura {

    fun celsiusParaFahrenheit(celsius: Double): Double {
        return (celsius * 9 / 5) + 32

    }

    fun FahrenheitParaCelsius(fahrenheit: Double): Double {
        return (fahrenheit - 32) * 5 / 9
    }
}