package br.com.fiap.conversordetemperatura

import junit.framework.TestCase.assertEquals
import org.junit.Test


class ConversorDeTemperaturaTest {


    private val conversor = ConversorDeTemperatura();

    @Test
    fun testCelsiusParaFahrenheit() {
        val result = conversor.celsiusParaFahrenheit(25.0)
        assertEquals(77.0, result, 0.01)
    }

    @Test
    fun testFahrenheitParaCelsius (){
        val result = conversor.FahrenheitParaCelsius(77.0)
        assertEquals(25.0, result, 0.01)
    }
}